import { useState } from "react";
import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import Doctors from "./components/Doctors";
import Treatments from "./components/Treatments";
import Promotions from "./components/Promotions";
import Odontogram from "./components/Odontogram";
import ClinicalHistory from "./components/ClinicalHistory";
import Reviews from "./components/Reviews";
import Location from "./components/Location";
import DentalTips from "./components/DentalTips";
import Gallery from "./components/Gallery";
import Suggestions from "./components/Suggestions";
import Footer from "./components/Footer";
import AppointmentModal from "./components/AppointmentModal";

export default function App() {
  const [bookModal, setBookModal] = useState(false);
  const [preDoctor, setPreDoctor] = useState("");
  const [preTreatment, setPreTreatment] = useState("");

  const openBook = (doctor?: string, treatment?: string) => {
    setPreDoctor(doctor || "");
    setPreTreatment(treatment || "");
    setBookModal(true);
  };

  return (
    <div style={{ background: "#fff", minHeight: "100vh" }}>
      <Navbar onBook={() => openBook()} />

      <main>
        <Hero onBook={() => openBook()} />
        <Doctors onBook={(doc) => openBook(doc)} />
        <Treatments onBook={(t) => openBook("", t)} />
        <Promotions />
        <Odontogram />
        <ClinicalHistory />
        <Reviews />
        <Location />
        <DentalTips />
        <Gallery />
        <Suggestions />
      </main>

      <Footer onBook={() => openBook()} />

      {/* Floating WhatsApp button */}
      <a
        href={`https://wa.me/5219984000000?text=${encodeURIComponent("Hola, quisiera obtener información sobre sus servicios dentales.")}`}
        target="_blank"
        rel="noopener noreferrer"
        className="fixed flex items-center justify-center rounded-full text-white text-2xl z-50 transition-all duration-300"
        style={{
          bottom: 24,
          right: 24,
          width: 56,
          height: 56,
          background: "#25D366",
          boxShadow: "0 4px 20px rgba(37,211,102,0.45)",
        }}
        title="Chatea con nosotros en WhatsApp"
        onMouseEnter={(e) => { e.currentTarget.style.transform = "scale(1.1)"; e.currentTarget.style.boxShadow = "0 8px 28px rgba(37,211,102,0.55)"; }}
        onMouseLeave={(e) => { e.currentTarget.style.transform = "scale(1)"; e.currentTarget.style.boxShadow = "0 4px 20px rgba(37,211,102,0.45)"; }}
      >
        💬
      </a>

      {bookModal && (
        <AppointmentModal
          onClose={() => setBookModal(false)}
          preDoctor={preDoctor}
          preTreatment={preTreatment}
        />
      )}
    </div>
  );
}
