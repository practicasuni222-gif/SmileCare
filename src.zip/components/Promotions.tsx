import { useState } from "react";
import { PROMOTIONS } from "../data/clinicData";
import { WA_NUMBER } from "../data/clinicData";

export default function Promotions() {
  const [selected, setSelected] = useState<(typeof PROMOTIONS)[0] | null>(null);

  const requestPromo = (promo: (typeof PROMOTIONS)[0]) => {
    const msg = encodeURIComponent(
      `Hola, me interesa la promoción:\n\n*${promo.title}* (${promo.discount})\n\n¿Podría darme más información y agendar una cita?`
    );
    window.open(`https://wa.me/${WA_NUMBER}?text=${msg}`, "_blank");
    setSelected(null);
  };

  return (
    <section id="promociones" className="py-20 px-4 md:px-8" style={{ background: "#F5F8FA" }}>
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-14">
          <div className="badge mb-4" style={{ background: "#FFF3E0", color: "#E65100" }}>🎉 Ofertas Especiales</div>
          <h2 className="section-title" style={{ fontSize: "clamp(1.8rem, 4vw, 2.6rem)", marginBottom: "1rem" }}>
            Promociones del Mes
          </h2>
          <div className="section-divider" />
          <p className="section-subtitle" style={{ maxWidth: 500, margin: "0 auto", lineHeight: 1.75 }}>
            Aprovecha nuestras promociones exclusivas y transforma tu sonrisa al mejor precio.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          {PROMOTIONS.map((promo) => (
            <div
              key={promo.id}
              className="card cursor-pointer overflow-hidden group"
              onClick={() => setSelected(promo)}
            >
              {/* Image with gradient */}
              <div className="relative overflow-hidden" style={{ height: 160 }}>
                <img
                  src={promo.image}
                  alt={promo.title}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  style={{ background: "#E2EBF0" }}
                />
                <div className={`absolute inset-0 bg-gradient-to-br ${promo.color} opacity-80`} />
                <div className="absolute inset-0 flex flex-col items-center justify-center text-white text-center p-4">
                  <div
                    style={{
                      fontFamily: "Outfit, sans-serif",
                      fontWeight: 900,
                      fontSize: "clamp(1.6rem, 5vw, 2.2rem)",
                      textShadow: "0 2px 8px rgba(0,0,0,0.3)",
                    }}
                  >
                    {promo.discount}
                  </div>
                  <div style={{ fontFamily: "Outfit, sans-serif", fontWeight: 600, fontSize: "1rem", opacity: 0.95 }}>
                    {promo.title}
                  </div>
                </div>
              </div>

              {/* Body */}
              <div className="p-5">
                <p style={{ fontFamily: "DM Sans, sans-serif", fontSize: "0.875rem", color: "#4A5C6D", lineHeight: 1.65, marginBottom: 12 }}>
                  {promo.description}
                </p>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <span style={{ fontSize: "0.7rem", color: "#6B7B8D" }}>📅</span>
                    <span style={{ fontFamily: "DM Sans, sans-serif", fontSize: "0.75rem", color: "#6B7B8D" }}>Válido hasta: {promo.validUntil}</span>
                  </div>
                  <button
                    className="btn-primary"
                    style={{ fontSize: "0.78rem", padding: "0.45rem 1rem" }}
                    onClick={(e) => { e.stopPropagation(); setSelected(promo); }}
                  >
                    Ver detalles
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Promo Modal */}
      {selected && (
        <div className="modal-overlay" onClick={(e) => e.target === e.currentTarget && setSelected(null)}>
          <div className="modal-box w-full" style={{ maxWidth: 500 }}>
            <div className={`relative p-8 rounded-t-2xl bg-gradient-to-br ${selected.color} text-white text-center`}>
              <button
                onClick={() => setSelected(null)}
                className="absolute top-4 right-4 w-8 h-8 rounded-full flex items-center justify-center"
                style={{ background: "rgba(255,255,255,0.25)", border: "none", cursor: "pointer", color: "white" }}
              >✕</button>
              <div style={{ fontFamily: "Outfit, sans-serif", fontWeight: 900, fontSize: "2.5rem" }}>{selected.discount}</div>
              <div style={{ fontFamily: "Outfit, sans-serif", fontWeight: 700, fontSize: "1.3rem" }}>{selected.title}</div>
            </div>

            <div className="p-6 flex flex-col gap-4">
              <div>
                <p className="font-semibold text-sm mb-1" style={{ fontFamily: "Outfit, sans-serif", color: "#1A2B3C" }}>📝 Descripción</p>
                <p style={{ fontFamily: "DM Sans, sans-serif", fontSize: "0.9rem", color: "#4A5C6D", lineHeight: 1.7 }}>{selected.description}</p>
              </div>

              <div className="rounded-xl p-4" style={{ background: "#FFF9E6", border: "1px solid #FDE68A" }}>
                <p className="font-semibold text-sm mb-1" style={{ fontFamily: "Outfit, sans-serif", color: "#92400E" }}>📋 Condiciones</p>
                <p style={{ fontFamily: "DM Sans, sans-serif", fontSize: "0.85rem", color: "#78350F" }}>{selected.conditions}</p>
              </div>

              <div className="flex items-center gap-2 px-4 py-3 rounded-xl" style={{ background: "#E8F9FB" }}>
                <span>📅</span>
                <span style={{ fontFamily: "DM Sans, sans-serif", fontSize: "0.85rem", color: "#0D94A6", fontWeight: 500 }}>
                  Vigencia: {selected.validUntil}
                </span>
              </div>

              <button
                className="btn-primary w-full justify-center"
                onClick={() => requestPromo(selected)}
              >
                💬 Solicitar esta promoción
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
