import { useState } from "react";
import { TREATMENTS } from "../data/clinicData";

interface Props {
  onBook: (treatment?: string) => void;
}

export default function Treatments({ onBook }: Props) {
  const [selected, setSelected] = useState<(typeof TREATMENTS)[0] | null>(null);

  return (
    <section id="tratamientos" className="py-20 px-4 md:px-8" style={{ background: "#fff" }}>
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-14">
          <div className="badge mb-4" style={{ background: "#E8F9FB", color: "#0D94A6" }}>🦷 Servicios</div>
          <h2 className="section-title" style={{ fontSize: "clamp(1.8rem, 4vw, 2.6rem)", marginBottom: "1rem" }}>
            Nuestros Tratamientos
          </h2>
          <div className="section-divider" />
          <p className="section-subtitle" style={{ maxWidth: 540, margin: "0 auto", lineHeight: 1.75 }}>
            Ofrecemos una amplia gama de tratamientos dentales con tecnología de última generación para cuidar tu salud bucal.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {TREATMENTS.map((t) => (
            <div key={t.id} className="card p-6 cursor-pointer group" onClick={() => setSelected(t)}>
              <div
                className="w-14 h-14 rounded-2xl flex items-center justify-center text-2xl mb-4 transition-transform duration-300 group-hover:scale-110"
                style={{ background: "linear-gradient(135deg, #E8F9FB, #EEF7FF)" }}
              >
                {t.icon}
              </div>
              <h3 style={{ fontFamily: "Outfit, sans-serif", fontWeight: 700, fontSize: "1.1rem", color: "#1A2B3C", marginBottom: 8 }}>
                {t.name}
              </h3>
              <p style={{ fontFamily: "DM Sans, sans-serif", fontSize: "0.875rem", color: "#6B7B8D", lineHeight: 1.65, marginBottom: 16 }}>
                {t.short}
              </p>
              <div className="flex items-center justify-between">
                <span style={{ fontFamily: "Outfit, sans-serif", fontWeight: 600, fontSize: "0.875rem", color: "#11B5C9" }}>{t.price}</span>
                <button
                  className="btn-outline"
                  style={{ fontSize: "0.78rem", padding: "0.45rem 1rem" }}
                  onClick={(e) => { e.stopPropagation(); setSelected(t); }}
                >
                  Más información
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Treatment Modal */}
      {selected && (
        <div className="modal-overlay" onClick={(e) => e.target === e.currentTarget && setSelected(null)}>
          <div className="modal-box w-full" style={{ maxWidth: 560 }}>
            <div className="flex items-center justify-between p-6 border-b" style={{ borderColor: "#E2EBF0" }}>
              <div className="flex items-center gap-3">
                <span className="text-2xl">{selected.icon}</span>
                <h2 style={{ fontFamily: "Outfit, sans-serif", fontWeight: 700, fontSize: "1.2rem", color: "#1A2B3C" }}>{selected.name}</h2>
              </div>
              <button
                onClick={() => setSelected(null)}
                className="w-8 h-8 flex items-center justify-center rounded-full"
                style={{ background: "#F5F8FA", color: "#6B7B8D", border: "none", cursor: "pointer" }}
              >✕</button>
            </div>
            <div className="p-6 flex flex-col gap-4">
              <p style={{ fontFamily: "DM Sans, sans-serif", color: "#4A5C6D", lineHeight: 1.75 }}>{selected.description}</p>

              <div className="grid grid-cols-2 gap-3">
                <InfoTile icon="⏱" label="Duración" value={selected.duration} />
                <InfoTile icon="💰" label="Precio aprox." value={selected.price} />
              </div>

              <div>
                <p className="font-semibold text-sm mb-2" style={{ fontFamily: "Outfit, sans-serif", color: "#1A2B3C" }}>✅ Beneficios</p>
                <ul className="flex flex-col gap-1.5">
                  {selected.benefits.map((b) => (
                    <li key={b} className="flex items-start gap-2">
                      <span style={{ color: "#11B5C9", marginTop: 2 }}>•</span>
                      <span style={{ fontFamily: "DM Sans, sans-serif", fontSize: "0.875rem", color: "#4A5C6D" }}>{b}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="rounded-xl p-4" style={{ background: "#F5F8FA" }}>
                <p className="font-semibold text-sm mb-1" style={{ fontFamily: "Outfit, sans-serif", color: "#1A2B3C" }}>📋 Indicaciones</p>
                <p style={{ fontFamily: "DM Sans, sans-serif", fontSize: "0.85rem", color: "#4A5C6D" }}>{selected.indications}</p>
              </div>

              <div className="rounded-xl p-4" style={{ background: "#FFF5F5", border: "1px solid #FED7D7" }}>
                <p className="font-semibold text-sm mb-1" style={{ fontFamily: "Outfit, sans-serif", color: "#C53030" }}>⚠️ Contraindicaciones</p>
                <p style={{ fontFamily: "DM Sans, sans-serif", fontSize: "0.85rem", color: "#742A2A" }}>{selected.contraindications}</p>
              </div>

              <button
                className="btn-primary w-full justify-center"
                onClick={() => { setSelected(null); onBook(selected.name); }}
              >
                📅 Agendar cita para {selected.name}
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}

function InfoTile({ icon, label, value }: { icon: string; label: string; value: string }) {
  return (
    <div className="rounded-xl p-3" style={{ background: "#E8F9FB" }}>
      <p style={{ fontFamily: "DM Sans, sans-serif", fontSize: "0.7rem", color: "#6B7B8D", marginBottom: 2 }}>{icon} {label}</p>
      <p style={{ fontFamily: "Outfit, sans-serif", fontWeight: 600, fontSize: "0.85rem", color: "#0D94A6" }}>{value}</p>
    </div>
  );
}
