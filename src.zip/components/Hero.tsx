interface Props {
  onBook: () => void;
}

export default function Hero({ onBook }: Props) {
  const scrollToTreatments = () => {
    const el = document.getElementById("tratamientos");
    if (el) el.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section
      id="inicio"
      className="relative min-h-screen flex items-center overflow-hidden"
      style={{ paddingTop: 70 }}
    >
      {/* Background */}
      <div className="absolute inset-0" style={{ background: "linear-gradient(145deg, #F0FCFE 0%, #E8F9FB 40%, #EEF7FF 100%)" }} />

      {/* Decorative circles */}
      <div className="absolute top-20 right-0 w-96 h-96 rounded-full opacity-20" style={{ background: "radial-gradient(circle, #11B5C9, transparent)", transform: "translate(30%, -20%)" }} />
      <div className="absolute bottom-0 left-0 w-72 h-72 rounded-full opacity-15" style={{ background: "radial-gradient(circle, #3B82F6, transparent)", transform: "translate(-30%, 30%)" }} />

      <div className="relative max-w-7xl mx-auto px-4 md:px-8 w-full py-16 grid md:grid-cols-2 gap-12 items-center">
        {/* Left */}
        <div className="animate-fade-in-up">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full mb-6" style={{ background: "#E8F9FB", border: "1px solid #B2EDF5" }}>
            <span className="w-2 h-2 rounded-full animate-pulse" style={{ background: "#11B5C9" }} />
            <span style={{ fontFamily: "DM Sans, sans-serif", fontSize: "0.8rem", color: "#0D94A6", fontWeight: 500 }}>Clínica de alta especialidad • Cancún, México</span>
          </div>

          <h1 style={{ fontFamily: "Outfit, sans-serif", fontWeight: 800, fontSize: "clamp(2.4rem, 5vw, 3.6rem)", lineHeight: 1.1, color: "#1A2B3C", marginBottom: "1.25rem" }}>
            Tu sonrisa perfecta{" "}
            <span style={{ color: "#11B5C9" }}>comienza aquí</span>
          </h1>

          <p style={{ fontFamily: "DM Sans, sans-serif", fontSize: "1.1rem", color: "#4A5C6D", lineHeight: 1.75, marginBottom: "2rem", maxWidth: 480 }}>
            En SmileCare combinamos tecnología de vanguardia con el cuidado más humano para brindarte tratamientos dentales de excelencia. Más de <strong>10,000 sonrisas transformadas.</strong>
          </p>

          {/* Stats */}
          <div className="flex gap-6 mb-8 flex-wrap">
            {[
              { num: "4+", label: "Especialistas" },
              { num: "15+", label: "Años de experiencia" },
              { num: "10K+", label: "Pacientes felices" },
            ].map((s) => (
              <div key={s.label} className="flex flex-col">
                <span style={{ fontFamily: "Outfit, sans-serif", fontWeight: 800, fontSize: "1.75rem", color: "#11B5C9", lineHeight: 1 }}>{s.num}</span>
                <span style={{ fontFamily: "DM Sans, sans-serif", fontSize: "0.8rem", color: "#6B7B8D" }}>{s.label}</span>
              </div>
            ))}
          </div>

          <div className="flex flex-wrap gap-3">
            <button className="btn-primary" onClick={onBook} style={{ fontSize: "1rem" }}>
              💬 Agendar cita por WhatsApp
            </button>
            <button className="btn-outline" onClick={scrollToTreatments} style={{ fontSize: "1rem" }}>
              Conocer más ↓
            </button>
          </div>

          {/* Trust badges */}
          <div className="flex flex-wrap gap-3 mt-6">
            {["✅ Sin dolor", "✅ Tecnología digital", "✅ Precios accesibles", "✅ Atención inmediata"].map((b) => (
              <span key={b} style={{ fontFamily: "DM Sans, sans-serif", fontSize: "0.8rem", color: "#4A5C6D" }}>{b}</span>
            ))}
          </div>
        </div>

        {/* Right - Image */}
        <div className="relative hidden md:block">
          <div className="relative">
            {/* Main image */}
            <div
              className="rounded-3xl overflow-hidden"
              style={{ boxShadow: "0 32px 80px rgba(17,181,201,0.2)" }}
            >
              <img
                src="https://images.unsplash.com/photo-1629909613654-28e377c37b09?w=700&h=600&fit=crop&auto=format"
                alt="SmileCare Clínica Dental — interior moderno"
                className="w-full object-cover"
                style={{ height: 480 }}
              />
              <div className="absolute inset-0 rounded-3xl" style={{ background: "linear-gradient(to top, rgba(17,181,201,0.08), transparent)" }} />
            </div>

            {/* Floating card 1 */}
            <div
              className="absolute -bottom-6 -left-8 flex items-center gap-3 px-4 py-3 rounded-2xl"
              style={{ background: "#fff", boxShadow: "0 8px 32px rgba(0,0,0,0.1)", minWidth: 180 }}
            >
              <div className="text-2xl">⭐</div>
              <div>
                <div style={{ fontFamily: "Outfit, sans-serif", fontWeight: 700, fontSize: "1.1rem", color: "#1A2B3C" }}>4.9 / 5.0</div>
                <div style={{ fontFamily: "DM Sans, sans-serif", fontSize: "0.72rem", color: "#6B7B8D" }}>+800 reseñas verificadas</div>
              </div>
            </div>

            {/* Floating card 2 */}
            <div
              className="absolute -top-5 -right-6 flex items-center gap-3 px-4 py-3 rounded-2xl"
              style={{ background: "#fff", boxShadow: "0 8px 32px rgba(0,0,0,0.1)" }}
            >
              <div className="w-8 h-8 rounded-full flex items-center justify-center" style={{ background: "#E8F9FB" }}>🦷</div>
              <div>
                <div style={{ fontFamily: "Outfit, sans-serif", fontWeight: 700, fontSize: "0.9rem", color: "#1A2B3C" }}>15+ tratamientos</div>
                <div style={{ fontFamily: "DM Sans, sans-serif", fontSize: "0.7rem", color: "#6B7B8D" }}>Especializados</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Wave bottom */}
      <div className="absolute bottom-0 left-0 right-0">
        <svg viewBox="0 0 1440 60" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M0 60L1440 60L1440 30C1200 0 960 60 720 30C480 0 240 60 0 30L0 60Z" fill="white"/>
        </svg>
      </div>
    </section>
  );
}
