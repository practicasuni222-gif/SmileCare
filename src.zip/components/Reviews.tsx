import { useState } from "react";
import { REVIEWS } from "../data/clinicData";

export default function Reviews() {
  const [showAll, setShowAll] = useState(false);
  const displayed = showAll ? REVIEWS : REVIEWS.slice(0, 3);

  return (
    <section className="py-20 px-4 md:px-8" style={{ background: "#fff" }}>
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-14">
          <div className="badge mb-4" style={{ background: "#FFF9E6", color: "#D97706" }}>⭐ Testimonios</div>
          <h2 className="section-title" style={{ fontSize: "clamp(1.8rem, 4vw, 2.6rem)", marginBottom: "1rem" }}>
            Lo que dicen nuestros pacientes
          </h2>
          <div className="section-divider" />
          <p className="section-subtitle" style={{ maxWidth: 480, margin: "0 auto" }}>
            Más de 800 reseñas verificadas. La satisfacción de nuestros pacientes es nuestra mayor recompensa.
          </p>
        </div>

        {/* Overall rating */}
        <div className="flex justify-center mb-10">
          <div className="flex items-center gap-8 px-8 py-5 rounded-2xl" style={{ background: "linear-gradient(135deg, #E8F9FB, #EEF7FF)", border: "1px solid #B2EDF5" }}>
            <div className="text-center">
              <div style={{ fontFamily: "Outfit, sans-serif", fontWeight: 900, fontSize: "3.5rem", color: "#11B5C9", lineHeight: 1 }}>4.9</div>
              <div className="flex gap-0.5 justify-center mt-1">{"★★★★★".split("").map((s, i) => <span key={i} style={{ color: "#F59E0B", fontSize: "1.2rem" }}>{s}</span>)}</div>
              <div style={{ fontFamily: "DM Sans, sans-serif", fontSize: "0.75rem", color: "#6B7B8D", marginTop: 4 }}>de 5.0</div>
            </div>
            <div className="w-px self-stretch" style={{ background: "#B2EDF5" }} />
            <div className="flex flex-col gap-2">
              {[5, 4, 3].map((stars) => {
                const count = REVIEWS.filter((r) => r.rating === stars).length;
                const pct = Math.round((count / REVIEWS.length) * 100);
                return (
                  <div key={stars} className="flex items-center gap-2">
                    <span style={{ fontFamily: "DM Sans, sans-serif", fontSize: "0.75rem", color: "#6B7B8D", width: 20 }}>{stars}★</span>
                    <div className="rounded-full overflow-hidden" style={{ width: 120, height: 6, background: "#E2EBF0" }}>
                      <div style={{ width: `${pct}%`, height: "100%", background: "#F59E0B", borderRadius: 4 }} />
                    </div>
                    <span style={{ fontFamily: "DM Sans, sans-serif", fontSize: "0.72rem", color: "#A0ADB8" }}>{count}</span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {displayed.map((r) => (
            <div key={r.id} className="card p-6 flex flex-col gap-3">
              <div className="flex items-center gap-3">
                <div
                  className="w-11 h-11 rounded-full flex items-center justify-center text-white font-bold text-sm flex-shrink-0"
                  style={{ background: "linear-gradient(135deg, #11B5C9, #3B82F6)", fontFamily: "Outfit, sans-serif" }}
                >
                  {r.avatar}
                </div>
                <div>
                  <p style={{ fontFamily: "Outfit, sans-serif", fontWeight: 700, fontSize: "0.95rem", color: "#1A2B3C" }}>{r.name}</p>
                  <p style={{ fontFamily: "DM Sans, sans-serif", fontSize: "0.72rem", color: "#6B7B8D" }}>{r.date}</p>
                </div>
                <div className="ml-auto flex gap-0.5">
                  {"★★★★★".slice(0, r.rating).split("").map((s, i) => <span key={i} style={{ color: "#F59E0B", fontSize: "0.9rem" }}>{s}</span>)}
                </div>
              </div>

              <p style={{ fontFamily: "DM Sans, sans-serif", fontSize: "0.875rem", color: "#4A5C6D", lineHeight: 1.7 }}>
                "{r.text}"
              </p>

              <div className="mt-auto">
                <span className="badge" style={{ background: "#E8F9FB", color: "#0D94A6", fontSize: "0.7rem" }}>
                  🦷 {r.treatment}
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* Toggle button */}
        <div className="text-center mt-8">
          <button
            className="btn-outline"
            onClick={() => setShowAll(!showAll)}
          >
            {showAll ? "▲ Ver menos" : "Ver todas las reseñas ▼"}
          </button>
        </div>
      </div>
    </section>
  );
}
