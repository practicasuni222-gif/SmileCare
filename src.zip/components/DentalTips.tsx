import { useState } from "react";
import { TIPS } from "../data/clinicData";

export default function DentalTips() {
  const [selected, setSelected] = useState<(typeof TIPS)[0] | null>(null);

  return (
    <section className="py-20 px-4 md:px-8" style={{ background: "#fff" }}>
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-14">
          <div className="badge mb-4" style={{ background: "#E8F9FB", color: "#0D94A6" }}>💡 Educación Dental</div>
          <h2 className="section-title" style={{ fontSize: "clamp(1.8rem, 4vw, 2.6rem)", marginBottom: "1rem" }}>
            Consejos para tu Salud Bucal
          </h2>
          <div className="section-divider" />
          <p className="section-subtitle" style={{ maxWidth: 480, margin: "0 auto" }}>
            Pequeños hábitos diarios que marcan una gran diferencia en la salud de tu boca.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {TIPS.map((tip) => (
            <div
              key={tip.id}
              className="card p-5 cursor-pointer group"
              onClick={() => setSelected(tip)}
            >
              <div
                className="w-12 h-12 rounded-xl flex items-center justify-center text-2xl mb-4 transition-transform duration-300 group-hover:scale-110"
                style={{ background: "linear-gradient(135deg, #E8F9FB, #EEF7FF)" }}
              >
                {tip.icon}
              </div>
              <h3 style={{ fontFamily: "Outfit, sans-serif", fontWeight: 700, fontSize: "1rem", color: "#1A2B3C", marginBottom: 6 }}>
                {tip.title}
              </h3>
              <p style={{ fontFamily: "DM Sans, sans-serif", fontSize: "0.85rem", color: "#6B7B8D", lineHeight: 1.65, marginBottom: 12 }}>
                {tip.summary}
              </p>
              <span style={{ fontFamily: "DM Sans, sans-serif", fontSize: "0.8rem", color: "#11B5C9", fontWeight: 500 }}>
                Leer artículo →
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Tip Article Modal */}
      {selected && (
        <div className="modal-overlay" onClick={(e) => e.target === e.currentTarget && setSelected(null)}>
          <div className="modal-box w-full" style={{ maxWidth: 520 }}>
            <div className="flex items-center justify-between p-6 border-b" style={{ borderColor: "#E2EBF0" }}>
              <div className="flex items-center gap-3">
                <span className="text-2xl">{selected.icon}</span>
                <h2 style={{ fontFamily: "Outfit, sans-serif", fontWeight: 700, fontSize: "1.2rem", color: "#1A2B3C" }}>
                  {selected.title}
                </h2>
              </div>
              <button
                onClick={() => setSelected(null)}
                className="w-8 h-8 flex items-center justify-center rounded-full"
                style={{ background: "#F5F8FA", border: "none", cursor: "pointer", color: "#6B7B8D" }}
              >✕</button>
            </div>
            <div className="p-6">
              <div
                className="w-full rounded-2xl flex items-center justify-center text-6xl mb-6"
                style={{ height: 140, background: "linear-gradient(135deg, #E8F9FB, #EEF7FF)" }}
              >
                {selected.icon}
              </div>
              <p className="section-subtitle text-sm font-medium mb-4" style={{ fontStyle: "italic" }}>{selected.summary}</p>
              <p style={{ fontFamily: "DM Sans, sans-serif", fontSize: "0.95rem", color: "#4A5C6D", lineHeight: 1.8 }}>
                {selected.content}
              </p>
              <div className="mt-6 p-4 rounded-xl flex items-start gap-3" style={{ background: "#E8F9FB" }}>
                <span className="text-lg">💡</span>
                <p style={{ fontFamily: "DM Sans, sans-serif", fontSize: "0.82rem", color: "#0D94A6", lineHeight: 1.6 }}>
                  ¿Tienes dudas sobre tu higiene bucal? Agenda una revisión preventiva gratuita con nuestros especialistas.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
