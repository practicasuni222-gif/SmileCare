import { useState } from "react";
import { WA_NUMBER, DOCTORS, TREATMENTS } from "../data/clinicData";

interface Props {
  onClose: () => void;
  preDoctor?: string;
  preTreatment?: string;
}

interface FormData {
  name: string;
  phone: string;
  date: string;
  time: string;
  doctor: string;
  treatment: string;
}

interface Errors {
  name?: string;
  phone?: string;
  date?: string;
  time?: string;
  doctor?: string;
  treatment?: string;
}

const TIME_SLOTS = [
  "9:00 AM", "9:30 AM", "10:00 AM", "10:30 AM", "11:00 AM", "11:30 AM",
  "12:00 PM", "12:30 PM", "1:00 PM", "2:00 PM", "3:00 PM", "3:30 PM",
  "4:00 PM", "4:30 PM", "5:00 PM", "5:30 PM", "6:00 PM", "6:30 PM", "7:00 PM",
];

export default function AppointmentModal({ onClose, preDoctor = "", preTreatment = "" }: Props) {
  const [form, setForm] = useState<FormData>({
    name: "", phone: "", date: "", time: "",
    doctor: preDoctor, treatment: preTreatment,
  });
  const [errors, setErrors] = useState<Errors>({});

  const today = new Date().toISOString().split("T")[0];

  const validate = (): boolean => {
    const e: Errors = {};
    if (!form.name.trim() || form.name.trim().length < 3) e.name = "Ingresa tu nombre completo";
    if (!form.phone.trim() || !/^\d{10}$/.test(form.phone.replace(/\s/g, ""))) e.phone = "Teléfono debe tener 10 dígitos";
    if (!form.date) e.date = "Selecciona una fecha";
    if (!form.time) e.time = "Selecciona una hora";
    if (!form.doctor) e.doctor = "Selecciona un doctor";
    if (!form.treatment) e.treatment = "Selecciona un tratamiento";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = () => {
    if (!validate()) return;
    const [year, month, day] = form.date.split("-");
    const dateStr = `${day}/${month}/${year}`;
    const msg = encodeURIComponent(
      `Hola, quiero agendar una cita en SmileCare Clínica Dental.\n\n` +
      `*Nombre:* ${form.name}\n` +
      `*Teléfono:* ${form.phone}\n` +
      `*Fecha:* ${dateStr}\n` +
      `*Hora:* ${form.time}\n` +
      `*Doctor:* ${form.doctor}\n` +
      `*Tratamiento:* ${form.treatment}`
    );
    window.open(`https://wa.me/${WA_NUMBER}?text=${msg}`, "_blank");
    onClose();
  };

  const field = (key: keyof FormData, label: string, node: React.ReactNode) => (
    <div>
      <label className="block text-sm font-semibold mb-1" style={{ fontFamily: "Outfit, sans-serif", color: "#1A2B3C" }}>
        {label} <span className="text-red-500">*</span>
      </label>
      {node}
      {errors[key] && <p className="text-xs mt-1" style={{ color: "#EF4444" }}>{errors[key]}</p>}
    </div>
  );

  return (
    <div className="modal-overlay" onClick={(e) => e.target === e.currentTarget && onClose()}>
      <div className="modal-box w-full" style={{ maxWidth: 520 }}>
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b" style={{ borderColor: "#E2EBF0" }}>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full flex items-center justify-center text-xl" style={{ background: "#E8F9FB" }}>
              📅
            </div>
            <div>
              <h2 style={{ fontFamily: "Outfit, sans-serif", fontSize: "1.2rem", fontWeight: 700, color: "#1A2B3C" }}>
                Agendar Cita
              </h2>
              <p style={{ fontSize: "0.8rem", color: "#6B7B8D" }}>Te contactaremos por WhatsApp</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 flex items-center justify-center rounded-full transition-colors"
            style={{ background: "#F5F8FA", color: "#6B7B8D" }}
            onMouseEnter={(e) => (e.currentTarget.style.background = "#E2EBF0")}
            onMouseLeave={(e) => (e.currentTarget.style.background = "#F5F8FA")}
          >
            ✕
          </button>
        </div>

        {/* Form */}
        <div className="p-6 flex flex-col gap-4">
          {field("name", "Nombre completo",
            <input
              className={`input-field ${errors.name ? "error" : ""}`}
              placeholder="Ej: Juan Pérez García"
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
            />
          )}

          {field("phone", "Teléfono celular (10 dígitos)",
            <input
              className={`input-field ${errors.phone ? "error" : ""}`}
              placeholder="Ej: 9984000000"
              value={form.phone}
              maxLength={10}
              onChange={(e) => setForm({ ...form, phone: e.target.value.replace(/\D/g, "") })}
            />
          )}

          <div className="grid grid-cols-2 gap-4">
            {field("date", "Fecha",
              <input
                type="date"
                className={`input-field ${errors.date ? "error" : ""}`}
                min={today}
                value={form.date}
                onChange={(e) => setForm({ ...form, date: e.target.value })}
              />
            )}

            {field("time", "Hora",
              <select
                className={`input-field ${errors.time ? "error" : ""}`}
                value={form.time}
                onChange={(e) => setForm({ ...form, time: e.target.value })}
              >
                <option value="">Seleccionar</option>
                {TIME_SLOTS.map((t) => <option key={t} value={t}>{t}</option>)}
              </select>
            )}
          </div>

          {field("doctor", "Doctor de preferencia",
            <select
              className={`input-field ${errors.doctor ? "error" : ""}`}
              value={form.doctor}
              onChange={(e) => setForm({ ...form, doctor: e.target.value })}
            >
              <option value="">Seleccionar doctor</option>
              {DOCTORS.map((d) => <option key={d.id} value={d.name}>{d.name} – {d.specialty}</option>)}
            </select>
          )}

          {field("treatment", "Tratamiento o motivo",
            <select
              className={`input-field ${errors.treatment ? "error" : ""}`}
              value={form.treatment}
              onChange={(e) => setForm({ ...form, treatment: e.target.value })}
            >
              <option value="">Seleccionar tratamiento</option>
              {TREATMENTS.map((t) => <option key={t.id} value={t.name}>{t.name}</option>)}
              <option value="Consulta de valoración">Consulta de valoración</option>
              <option value="Revisión general">Revisión general</option>
            </select>
          )}

          <button
            className="btn-primary w-full justify-center mt-2"
            onClick={handleSubmit}
          >
            <span>💬</span> Continuar por WhatsApp
          </button>

          <p className="text-center text-xs" style={{ color: "#A0ADB8" }}>
            Al presionar serás redirigido a WhatsApp con tu información lista.
          </p>
        </div>
      </div>
    </div>
  );
}
