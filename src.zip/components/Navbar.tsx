import { useState, useEffect } from "react";

interface Props {
  onBook: () => void;
}

const NAV_LINKS = [
  { label: "Inicio", href: "inicio" },
  { label: "Doctores", href: "doctores" },
  { label: "Tratamientos", href: "tratamientos" },
  { label: "Promociones", href: "promociones" },
  { label: "Contacto", href: "contacto" },
];

export default function Navbar({ onBook }: Props) {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [active, setActive] = useState("inicio");

  useEffect(() => {
    const onScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const scrollTo = (id: string) => {
    setMenuOpen(false);
    setActive(id);
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  return (
    <nav
      className="fixed top-0 left-0 right-0 z-50 transition-all duration-300"
      style={{
        background: scrolled ? "rgba(255,255,255,0.97)" : "rgba(255,255,255,0.92)",
        backdropFilter: "blur(12px)",
        boxShadow: scrolled ? "0 2px 20px rgba(17,181,201,0.12)" : "none",
        borderBottom: scrolled ? "1px solid #E2EBF0" : "1px solid transparent",
      }}
    >
      <div className="max-w-7xl mx-auto px-4 md:px-8 flex items-center justify-between" style={{ height: 70 }}>
        {/* Logo */}
        <button onClick={() => scrollTo("inicio")} className="flex items-center gap-2 cursor-pointer" style={{ background: "none", border: "none", padding: 0 }}>
          <div
            className="w-10 h-10 rounded-full flex items-center justify-center text-white text-lg font-bold"
            style={{ background: "linear-gradient(135deg, #11B5C9, #3B82F6)", fontFamily: "Outfit, sans-serif" }}
          >
            S
          </div>
          <div className="flex flex-col leading-none">
            <span style={{ fontFamily: "Outfit, sans-serif", fontWeight: 800, fontSize: "1.05rem", color: "#1A2B3C" }}>SmileCare</span>
            <span style={{ fontFamily: "DM Sans, sans-serif", fontSize: "0.65rem", color: "#11B5C9", letterSpacing: "0.12em", fontWeight: 500, textTransform: "uppercase" }}>Clínica Dental</span>
          </div>
        </button>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center gap-1">
          {NAV_LINKS.map((link) => (
            <button
              key={link.href}
              onClick={() => scrollTo(link.href)}
              className="px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200"
              style={{
                fontFamily: "DM Sans, sans-serif",
                fontWeight: 500,
                color: active === link.href ? "#11B5C9" : "#3D5066",
                background: active === link.href ? "#E8F9FB" : "transparent",
                border: "none",
                cursor: "pointer",
              }}
              onMouseEnter={(e) => {
                if (active !== link.href) e.currentTarget.style.background = "#F5F8FA";
              }}
              onMouseLeave={(e) => {
                if (active !== link.href) e.currentTarget.style.background = "transparent";
              }}
            >
              {link.label}
            </button>
          ))}
        </div>

        {/* CTA */}
        <div className="hidden md:flex items-center gap-3">
          <a
            href="tel:+5219984000000"
            className="flex items-center gap-2 text-sm font-medium transition-colors"
            style={{ fontFamily: "DM Sans, sans-serif", color: "#6B7B8D", textDecoration: "none" }}
            onMouseEnter={(e) => (e.currentTarget.style.color = "#11B5C9")}
            onMouseLeave={(e) => (e.currentTarget.style.color = "#6B7B8D")}
          >
            📞 <span>(998) 400-0000</span>
          </a>
          <button className="btn-primary" onClick={onBook} style={{ fontSize: "0.875rem", padding: "0.6rem 1.25rem" }}>
            📅 Agenda tu cita
          </button>
        </div>

        {/* Mobile toggle */}
        <button
          className="md:hidden flex flex-col gap-1.5 p-2 rounded-lg"
          onClick={() => setMenuOpen(!menuOpen)}
          style={{ background: menuOpen ? "#E8F9FB" : "transparent", border: "none", cursor: "pointer" }}
          aria-label="Menú"
        >
          {[0, 1, 2].map((i) => (
            <span
              key={i}
              className="block transition-all duration-200"
              style={{
                width: 22,
                height: 2,
                background: "#11B5C9",
                borderRadius: 2,
                transform: menuOpen
                  ? i === 0 ? "rotate(45deg) translateY(6px)" : i === 2 ? "rotate(-45deg) translateY(-6px)" : "scaleX(0)"
                  : "none",
                opacity: menuOpen && i === 1 ? 0 : 1,
              }}
            />
          ))}
        </button>
      </div>

      {/* Mobile menu */}
      {menuOpen && (
        <div
          className="md:hidden border-t px-4 py-4 flex flex-col gap-1"
          style={{ background: "#fff", borderColor: "#E2EBF0" }}
        >
          {NAV_LINKS.map((link) => (
            <button
              key={link.href}
              onClick={() => scrollTo(link.href)}
              className="text-left px-4 py-3 rounded-xl text-sm font-medium transition-colors"
              style={{
                fontFamily: "DM Sans, sans-serif",
                fontWeight: 500,
                color: active === link.href ? "#11B5C9" : "#3D5066",
                background: active === link.href ? "#E8F9FB" : "transparent",
                border: "none",
                cursor: "pointer",
              }}
            >
              {link.label}
            </button>
          ))}
          <button className="btn-primary w-full justify-center mt-2" onClick={onBook}>
            📅 Agenda tu cita
          </button>
        </div>
      )}
    </nav>
  );
}
