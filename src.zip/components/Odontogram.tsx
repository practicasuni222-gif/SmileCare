import { useState } from "react";

type ToothStatus = "sano" | "tratamiento" | "caries" | "extraccion" | "protesis" | "urgente";

interface ToothState {
  status: ToothStatus;
  note: string;
}

const STATUS_CONFIG: Record<ToothStatus, { label: string; color: string; bg: string; emoji: string }> = {
  sano: { label: "Sano", color: "#16A34A", bg: "#DCFCE7", emoji: "✅" },
  tratamiento: { label: "Tratamiento", color: "#D97706", bg: "#FEF3C7", emoji: "🔧" },
  caries: { label: "Caries", color: "#DC2626", bg: "#FEE2E2", emoji: "🦠" },
  extraccion: { label: "Extracción", color: "#7C3AED", bg: "#EDE9FE", emoji: "❌" },
  protesis: { label: "Prótesis", color: "#2563EB", bg: "#DBEAFE", emoji: "👑" },
  urgente: { label: "Urgente", color: "#B91C1C", bg: "#FEE2E2", emoji: "🚨" },
};

// FDI notation: upper right 18-11, upper left 21-28, lower left 31-38, lower right 48-41
const UPPER_RIGHT = [18, 17, 16, 15, 14, 13, 12, 11];
const UPPER_LEFT  = [21, 22, 23, 24, 25, 26, 27, 28];
const LOWER_LEFT  = [31, 32, 33, 34, 35, 36, 37, 38];
const LOWER_RIGHT = [48, 47, 46, 45, 44, 43, 42, 41];

export default function Odontogram() {
  const [teeth, setTeeth] = useState<Record<number, ToothState>>({});
  const [activeMenu, setActiveMenu] = useState<number | null>(null);
  const [noteInput, setNoteInput] = useState("");
  const [saved, setSaved] = useState(false);
  const [globalNote, setGlobalNote] = useState("");

  const getTooth = (id: number): ToothState => teeth[id] || { status: "sano", note: "" };

  const setStatus = (id: number, status: ToothStatus) => {
    setTeeth((prev) => ({ ...prev, [id]: { ...getTooth(id), status } }));
    setActiveMenu(null);
  };

  const openMenu = (id: number) => {
    setNoteInput(getTooth(id).note);
    setActiveMenu(activeMenu === id ? null : id);
  };

  const saveNote = (id: number) => {
    setTeeth((prev) => ({ ...prev, [id]: { ...getTooth(id), note: noteInput } }));
    setActiveMenu(null);
  };

  const handleSave = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  const ToothButton = ({ id }: { id: number }) => {
    const { status, note } = getTooth(id);
    const cfg = STATUS_CONFIG[status];
    const isActive = activeMenu === id;
    return (
      <div className="relative">
        <button
          className="tooth-btn flex-col"
          style={{
            background: cfg.bg,
            borderColor: isActive ? "#11B5C9" : cfg.color,
            color: cfg.color,
            outline: isActive ? "2px solid #11B5C9" : "none",
          }}
          onClick={() => openMenu(id)}
          title={`Diente ${id} — ${cfg.label}${note ? ` — ${note}` : ""}`}
        >
          <span style={{ fontSize: "0.55rem", lineHeight: 1 }}>{id}</span>
          <span style={{ fontSize: "0.75rem" }}>{cfg.emoji}</span>
        </button>

        {/* Menu */}
        {isActive && (
          <div
            className="absolute z-50 rounded-xl shadow-xl p-3 flex flex-col gap-1"
            style={{
              background: "#fff",
              border: "1px solid #E2EBF0",
              minWidth: 160,
              top: "calc(100% + 8px)",
              left: "50%",
              transform: "translateX(-50%)",
            }}
          >
            <p style={{ fontFamily: "Outfit, sans-serif", fontWeight: 700, fontSize: "0.75rem", color: "#6B7B8D", marginBottom: 4 }}>
              Diente {id}
            </p>
            {(Object.entries(STATUS_CONFIG) as [ToothStatus, typeof STATUS_CONFIG[ToothStatus]][]).map(([key, cfg]) => (
              <button
                key={key}
                onClick={() => setStatus(id, key)}
                className="flex items-center gap-2 rounded-lg px-2 py-1.5 text-left text-xs transition-colors"
                style={{
                  border: "none",
                  cursor: "pointer",
                  background: status === key ? cfg.bg : "transparent",
                  color: cfg.color,
                  fontFamily: "DM Sans, sans-serif",
                  fontWeight: 500,
                }}
                onMouseEnter={(e) => (e.currentTarget.style.background = cfg.bg)}
                onMouseLeave={(e) => (e.currentTarget.style.background = status === key ? cfg.bg : "transparent")}
              >
                {cfg.emoji} {cfg.label}
              </button>
            ))}
            <div className="mt-2 border-t pt-2" style={{ borderColor: "#E2EBF0" }}>
              <input
                className="input-field"
                style={{ fontSize: "0.75rem", padding: "0.4rem 0.6rem" }}
                placeholder="Nota del diente..."
                value={noteInput}
                onChange={(e) => setNoteInput(e.target.value)}
              />
              <button
                className="btn-primary w-full justify-center mt-2"
                style={{ fontSize: "0.72rem", padding: "0.4rem" }}
                onClick={() => saveNote(id)}
              >
                Guardar nota
              </button>
            </div>
          </div>
        )}
      </div>
    );
  };

  const Row = ({ ids, label }: { ids: number[]; label: string }) => (
    <div className="flex items-center gap-1">
      <span style={{ fontFamily: "DM Sans, sans-serif", fontSize: "0.65rem", color: "#A0ADB8", width: 40, textAlign: "right", flexShrink: 0 }}>{label}</span>
      <div className="flex gap-1 flex-wrap">
        {ids.map((id) => <ToothButton key={id} id={id} />)}
      </div>
    </div>
  );

  return (
    <section className="py-20 px-4 md:px-8" style={{ background: "#fff" }}>
      <div className="max-w-5xl mx-auto">
        <div className="text-center mb-10">
          <div className="badge mb-4" style={{ background: "#E8F9FB", color: "#0D94A6" }}>🦷 Herramienta Clínica</div>
          <h2 className="section-title" style={{ fontSize: "clamp(1.8rem, 4vw, 2.4rem)", marginBottom: "0.75rem" }}>
            Odontograma Digital
          </h2>
          <div className="section-divider" />
          <p className="section-subtitle" style={{ maxWidth: 500, margin: "0 auto" }}>
            Haz clic en cualquier diente para asignarle un estado y agregar notas clínicas.
          </p>
        </div>

        {/* Legend */}
        <div className="flex flex-wrap gap-2 justify-center mb-8">
          {(Object.entries(STATUS_CONFIG) as [ToothStatus, typeof STATUS_CONFIG[ToothStatus]][]).map(([key, cfg]) => (
            <span key={key} className="badge" style={{ background: cfg.bg, color: cfg.color }}>
              {cfg.emoji} {cfg.label}
            </span>
          ))}
        </div>

        {/* Chart */}
        <div
          className="rounded-2xl p-6 overflow-x-auto"
          style={{ background: "#F5F8FA", border: "1px solid #E2EBF0" }}
          onClick={(e) => { if (e.target === e.currentTarget) setActiveMenu(null); }}
        >
          <div className="flex flex-col gap-3 min-w-max mx-auto" style={{ width: "fit-content" }}>
            {/* Upper arch */}
            <div className="text-center mb-1">
              <span style={{ fontFamily: "Outfit, sans-serif", fontWeight: 600, fontSize: "0.75rem", color: "#11B5C9" }}>ARCADA SUPERIOR</span>
            </div>
            <div className="flex gap-4 items-center justify-center">
              <Row ids={UPPER_RIGHT} label="Der ↑" />
              <div className="w-px h-10 mx-2" style={{ background: "#CBD5E1" }} />
              <Row ids={UPPER_LEFT} label="Izq ↑" />
            </div>

            {/* Midline */}
            <div className="flex items-center gap-2 my-1">
              <div className="flex-1 h-px" style={{ background: "#CBD5E1" }} />
              <span style={{ fontFamily: "DM Sans, sans-serif", fontSize: "0.65rem", color: "#A0ADB8" }}>LÍNEA MEDIA</span>
              <div className="flex-1 h-px" style={{ background: "#CBD5E1" }} />
            </div>

            {/* Lower arch */}
            <div className="flex gap-4 items-center justify-center">
              <Row ids={LOWER_RIGHT} label="Der ↓" />
              <div className="w-px h-10 mx-2" style={{ background: "#CBD5E1" }} />
              <Row ids={LOWER_LEFT} label="Izq ↓" />
            </div>
            <div className="text-center mt-1">
              <span style={{ fontFamily: "Outfit, sans-serif", fontWeight: 600, fontSize: "0.75rem", color: "#11B5C9" }}>ARCADA INFERIOR</span>
            </div>
          </div>
        </div>

        {/* Summary + notes */}
        <div className="mt-6 grid md:grid-cols-2 gap-4">
          {/* Summary */}
          <div className="rounded-xl p-4" style={{ background: "#F5F8FA", border: "1px solid #E2EBF0" }}>
            <p style={{ fontFamily: "Outfit, sans-serif", fontWeight: 600, fontSize: "0.9rem", color: "#1A2B3C", marginBottom: 8 }}>
              📊 Resumen del Odontograma
            </p>
            {(Object.entries(STATUS_CONFIG) as [ToothStatus, typeof STATUS_CONFIG[ToothStatus]][]).map(([key, cfg]) => {
              const count = Object.values(teeth).filter((t) => t.status === key).length;
              if (!count && key === "sano") return null;
              return (
                <div key={key} className="flex items-center justify-between py-1">
                  <span style={{ fontFamily: "DM Sans, sans-serif", fontSize: "0.8rem", color: cfg.color }}>{cfg.emoji} {cfg.label}</span>
                  <span className="badge" style={{ background: cfg.bg, color: cfg.color, fontSize: "0.7rem" }}>{count} dientes</span>
                </div>
              );
            })}
            {Object.keys(teeth).length === 0 && (
              <p style={{ fontFamily: "DM Sans, sans-serif", fontSize: "0.8rem", color: "#A0ADB8" }}>Sin cambios registrados aún.</p>
            )}
          </div>

          {/* Notes */}
          <div className="rounded-xl p-4" style={{ background: "#F5F8FA", border: "1px solid #E2EBF0" }}>
            <p style={{ fontFamily: "Outfit, sans-serif", fontWeight: 600, fontSize: "0.9rem", color: "#1A2B3C", marginBottom: 8 }}>
              📝 Notas Generales
            </p>
            <textarea
              className="input-field"
              rows={4}
              placeholder="Observaciones generales del paciente..."
              value={globalNote}
              onChange={(e) => setGlobalNote(e.target.value)}
              style={{ resize: "none" }}
            />
          </div>
        </div>

        {/* Save button */}
        <div className="flex items-center gap-3 mt-4 justify-end">
          {saved && (
            <span style={{ fontFamily: "DM Sans, sans-serif", fontSize: "0.875rem", color: "#16A34A" }}>
              ✅ Odontograma guardado correctamente
            </span>
          )}
          <button className="btn-primary" onClick={handleSave}>
            💾 Guardar Odontograma
          </button>
        </div>
      </div>
    </section>
  );
}
