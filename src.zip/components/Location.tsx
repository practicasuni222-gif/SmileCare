export default function Location() {
  const mapsUrl = "https://www.google.com/maps/search/Cancún+Clínica+Dental/@21.1619,-86.8515,14z";
  const directionsUrl = "https://www.google.com/maps/dir/?api=1&destination=21.1619,-86.8515&travelmode=driving";

  return (
    <section id="contacto" className="py-20 px-4 md:px-8" style={{ background: "#F5F8FA" }}>
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-14">
          <div className="badge mb-4" style={{ background: "#E8F9FB", color: "#0D94A6" }}>📍 Ubicación</div>
          <h2 className="section-title" style={{ fontSize: "clamp(1.8rem, 4vw, 2.6rem)", marginBottom: "1rem" }}>
            ¿Dónde estamos?
          </h2>
          <div className="section-divider" />
          <p className="section-subtitle" style={{ maxWidth: 480, margin: "0 auto" }}>
            Visítanos en nuestras instalaciones de última generación, ubicadas en el corazón de Cancún.
          </p>
        </div>

        <div className="grid md:grid-cols-5 gap-6 items-start">
          {/* Info */}
          <div className="md:col-span-2 flex flex-col gap-4">
            {[
              { icon: "📍", label: "Dirección", value: "Av. Tulum 456, Col. Centro\nCancún, Q. Roo, C.P. 77500" },
              { icon: "📞", label: "Teléfono", value: "(998) 400-0000\n(998) 400-0001" },
              { icon: "✉️", label: "Correo", value: "contacto@smilecare.mx" },
              { icon: "🕐", label: "Horario de atención", value: "Lunes a Viernes: 9:00 AM – 8:00 PM\nSábados: 9:00 AM – 3:00 PM" },
            ].map((info) => (
              <div key={info.label} className="card p-4 flex gap-4 items-start">
                <span className="text-2xl">{info.icon}</span>
                <div>
                  <p style={{ fontFamily: "Outfit, sans-serif", fontWeight: 600, fontSize: "0.85rem", color: "#1A2B3C", marginBottom: 4 }}>{info.label}</p>
                  <p style={{ fontFamily: "DM Sans, sans-serif", fontSize: "0.85rem", color: "#6B7B8D", whiteSpace: "pre-line", lineHeight: 1.6 }}>{info.value}</p>
                </div>
              </div>
            ))}

            <button
              className="btn-primary w-full justify-center"
              onClick={() => window.open(directionsUrl, "_blank")}
            >
              🗺️ Cómo llegar
            </button>
          </div>

          {/* Map */}
          <div className="md:col-span-3 rounded-2xl overflow-hidden" style={{ height: 420, boxShadow: "0 8px 32px rgba(17,181,201,0.12)", border: "1px solid #E2EBF0" }}>
            <iframe
              title="SmileCare Clínica Dental - Mapa"
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3724.0!2d-86.8515!3d21.1619!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMjHCsDA5JzQyLjgiTiA4NsKwNTEnMDUuNCJX!5e0!3m2!1ses!2smx!4v1690000000000!5m2!1ses!2smx"
              width="100%"
              height="100%"
              style={{ border: 0 }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
