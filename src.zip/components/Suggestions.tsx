import { useState } from "react";

interface Form {
  name: string;
  email: string;
  message: string;
}

interface Errors {
  name?: string;
  email?: string;
  message?: string;
}

export default function Suggestions() {
  const [form, setForm] = useState<Form>({ name: "", email: "", message: "" });
  const [errors, setErrors] = useState<Errors>({});
  const [sent, setSent] = useState(false);
  const [loading, setLoading] = useState(false);

  const validate = (): boolean => {
    const e: Errors = {};
    if (!form.name.trim() || form.name.trim().length < 2) e.name = "Ingresa tu nombre completo";
    if (!form.email.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) e.email = "Ingresa un correo válido";
    if (!form.message.trim() || form.message.trim().length < 15) e.message = "El mensaje debe tener al menos 15 caracteres";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setSent(true);
      setForm({ name: "", email: "", message: "" });
    }, 1200);
  };

  return (
    <section className="py-20 px-4 md:px-8" style={{ background: "#fff" }}>
      <div className="max-w-2xl mx-auto">
        <div className="text-center mb-10">
          <div className="badge mb-4" style={{ background: "#E8F9FB", color: "#0D94A6" }}>💬 Feedback</div>
          <h2 className="section-title" style={{ fontSize: "clamp(1.8rem, 4vw, 2.4rem)", marginBottom: "0.75rem" }}>
            Tu opinión nos importa
          </h2>
          <div className="section-divider" />
          <p className="section-subtitle" style={{ maxWidth: 420, margin: "0 auto" }}>
            Comparte tus sugerencias o comentarios. Juntos mejoramos la experiencia de cada paciente.
          </p>
        </div>

        {sent ? (
          <div
            className="text-center py-16 px-8 rounded-3xl"
            style={{ background: "linear-gradient(135deg, #E8F9FB, #EEF7FF)", border: "1px solid #B2EDF5" }}
          >
            <div className="text-5xl mb-4">🎉</div>
            <h3 style={{ fontFamily: "Outfit, sans-serif", fontWeight: 800, fontSize: "1.5rem", color: "#1A2B3C", marginBottom: 8 }}>
              ¡Gracias por tu sugerencia!
            </h3>
            <p style={{ fontFamily: "DM Sans, sans-serif", color: "#4A5C6D", lineHeight: 1.7, marginBottom: 24 }}>
              Tu mensaje ha sido recibido. Nuestro equipo lo revisará y trabajará para mejorar tu experiencia en SmileCare.
            </p>
            <button className="btn-primary" onClick={() => setSent(false)}>
              Enviar otra sugerencia
            </button>
          </div>
        ) : (
          <form
            onSubmit={handleSubmit}
            className="card p-8 flex flex-col gap-5"
            noValidate
          >
            <div>
              <label className="block text-sm font-semibold mb-1.5" style={{ fontFamily: "Outfit, sans-serif", color: "#1A2B3C" }}>
                Nombre completo *
              </label>
              <input
                className={`input-field ${errors.name ? "error" : ""}`}
                placeholder="Tu nombre"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
              />
              {errors.name && <p className="text-xs mt-1" style={{ color: "#EF4444" }}>{errors.name}</p>}
            </div>

            <div>
              <label className="block text-sm font-semibold mb-1.5" style={{ fontFamily: "Outfit, sans-serif", color: "#1A2B3C" }}>
                Correo electrónico *
              </label>
              <input
                type="email"
                className={`input-field ${errors.email ? "error" : ""}`}
                placeholder="tu@correo.com"
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
              />
              {errors.email && <p className="text-xs mt-1" style={{ color: "#EF4444" }}>{errors.email}</p>}
            </div>

            <div>
              <label className="block text-sm font-semibold mb-1.5" style={{ fontFamily: "Outfit, sans-serif", color: "#1A2B3C" }}>
                Sugerencia o comentario *
              </label>
              <textarea
                className={`input-field ${errors.message ? "error" : ""}`}
                rows={5}
                placeholder="Comparte tu experiencia o sugerencia para mejorar nuestro servicio..."
                value={form.message}
                onChange={(e) => setForm({ ...form, message: e.target.value })}
                style={{ resize: "none" }}
              />
              {errors.message && <p className="text-xs mt-1" style={{ color: "#EF4444" }}>{errors.message}</p>}
              <p className="text-xs mt-1 text-right" style={{ color: "#A0ADB8" }}>{form.message.length}/500</p>
            </div>

            <button
              type="submit"
              className="btn-primary w-full justify-center"
              disabled={loading}
            >
              {loading ? (
                <span className="flex items-center gap-2">
                  <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin inline-block" />
                  Enviando...
                </span>
              ) : (
                "📨 Enviar sugerencia"
              )}
            </button>
          </form>
        )}
      </div>
    </section>
  );
}
